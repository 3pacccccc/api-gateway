package org.imooc.common.constants;

public interface GatewayConst {
	
	String UNIQUE_ID = "uniqueId";
	
	String DEFAULT_VERSION = "1.0.0";
	
	String PROTOCOL_KEY = "protocol";
	
}
