package org.imooc.core.config;

/**
 * @PROJECT_NAME: api-gateway
 * @DESCRIPTION:
 * @USER: WuYang
 * @DATE: 2022/12/24 16:29
 */
public class Rule {
}
