package org.imooc.common.config;

/**
 * http协议的注册服务调用模型类
 */
public class HttpServiceInvoker extends AbstractServiceInvoker {

}
