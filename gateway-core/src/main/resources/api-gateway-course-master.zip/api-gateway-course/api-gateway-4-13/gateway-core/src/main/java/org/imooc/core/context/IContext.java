package org.imooc.core.context;

import io.netty.channel.ChannelHandlerContext;
import org.imooc.gateway.common.config.Rule;

import java.util.function.Consumer;

/**
 * 首先我们来思考一个问题，网关有生命周期吗？我们可以看我们的线程池吗？
 * 其实是有的，线程池一共有5种生命周期，有Running，ShutDown、STOP等，
 * 那么网关也需要生命周期，我们的
 * 网关上下文接口定义
 * 主要分3部分
 *
 * 1.上下文生命周期相关：
 * 		1.1 定义状态
 * 		1.2 状态流转方法
 * 		1.3 判断状态方法
 *
 * 	2.获取 转换协议，请求对象，响应对象，异常
 *
 * 	3.设置 响应对象，异常
 *
 * 	主要用到的就是这些，后面有其它的我们再继续扩展
 */
public interface IContext {

	/** 上下文生命周期，定义状态 **/

	//	一个请求正在执行过程中
	int RUNNING = -1;

	// 中途出现错误，比如运行完过滤器过程中，不一定哪一个出错，这时我们需要进行标记，
	// 告诉我们请求以及结束，需要返回客户端
	int WRITTEN = 0;
	
	//	当写回成功后, 设置该标记，如果是Netty的话：ctx.writeAndFlush(response);防止并发下的多次标记写回
	int COMPLETED = 1;
	
	//	表示整个网关请求完毕, 彻底结束
	int TERMINATED = 2;




	/** 上下文生命周期，状态流转 **/

	/**
	 * <B>概要说明：</B>设置上下文状态为正常运行状态<BR>
	 */
	void runned();
	
	/**
	 * <B>概要说明：</B>设置上下文状态为标记写回<BR>
	 */
	void writtened();
	
	/**
	 * <B>概要说明：</B>设置上下文状态为写回结束<BR>
	 */
	void completed();
	
	/**
	 * <B>概要说明：</B>设置上下文状态为最终结束<BR>
	 */
	void terminated();
	
	/*************** -- 判断网关的状态 -- ********************/
	
	boolean isRunning();
	
	boolean isWrittened();
	
	boolean isCompleted();
	
	boolean isTerminated();



	/**
	 * <B>方法名称：</B>getProtocol<BR>
	 * <B>概要说明：</B>获取请求转换协议<BR>
	 * @return
	 */
	String getProtocol();

	/**
	 * 获取规则
	 * @return
	 */
	Rule getRule();

	/**
	 * <B>方法名称：</B>getRequest<BR>
	 * <B>概要说明：</B>获取请求对象<BR>
	 * @return
	 */
	Object getRequest();
	
	/**
	 * <B>方法名称：</B>getResponse<BR>
	 * <B>概要说明：</B>获取响应对象<BR>
	 * @return
	 */
	Object getResponse();

	/**
	 * <B>方法名称：</B>setResponse<BR>
	 * <B>概要说明：</B>设置响应对象<BR>
	 * @param response
	 */
	void setResponse(Object response);

	/**
	 * 设置异常信息
	 * @param throwable
	 */
	void setThrowable(Throwable throwable);

	/**
	 * <B>方法名称：</B>getThrowable<BR>
	 * <B>概要说明：</B>获取异常<BR>
	 * @return Throwable
	 */
	Throwable getThrowable();

	/**
	 * 获取上下文参数
	 * @param key
	 * @return
	 * @param <T>
	 */
	<T> T getAttribute(String key);

	/**
	 *
	 * @param key
	 * @param value
	 * @return
	 * @param <T>
	 */
	<T> T putAttribute(String key, T value);

	/**
	 * 获取Netty上下文
	 *
	 * @return
	 */
	ChannelHandlerContext getNettyCtx();

	/**
	 * 是否保持连接
	 * @return
	 */
	boolean isKeepAlive();

	/**
	 * 释放请求资源的方法
	 */
	void releaseRequest();

	/**
	 * <B>方法名称：</B>completedCallback<BR>
	 * <B>概要说明：</B>写回接收回调函数设置<BR>
	 * @author JiFeng
	 * @since 2021年12月9日 上午2:30:02
	 * @param consumer
	 */
	void completedCallback(Consumer<IContext> consumer);
	/**
	 * <B>方法名称：</B>invokeCompletedCallback<BR>
	 * <B>概要说明：</B>回调函数执行<BR>
	 * @author JiFeng
	 * @since 2021年12月9日 上午2:30:41
	 */
	void invokeCompletedCallback();
}
