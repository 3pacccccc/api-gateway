package org.imooc.core.context;

import io.netty.channel.ChannelHandlerContext;
import org.imooc.core.config.Rule;
import org.imooc.core.request.GatewayRequest;
import org.imooc.core.response.GatewayResponse;

/**
 * @PROJECT_NAME: api-gateway
 * @DESCRIPTION: 网关核心上下文类
 * @USER: WuYang
 * @DATE: 2022/12/29 20:59
 */
public class GatewayContext extends BasicContext{

    private GatewayRequest request;

    private GatewayResponse response;

    private Rule rule;

    /**
     * 构造函数
     *
     * @param protocol
     * @param nettyCtx
     * @param keepAlive
     */
    public GatewayContext(String protocol, ChannelHandlerContext nettyCtx, boolean keepAlive) {
        super(protocol, nettyCtx, keepAlive);
    }
}
