package org.imooc.core.response;

/**
 * @PROJECT_NAME: api-gateway
 * @DESCRIPTION:
 * @USER: WuYang
 * @DATE: 2022/12/29 21:01
 */
public class GatewayResponse {
}
