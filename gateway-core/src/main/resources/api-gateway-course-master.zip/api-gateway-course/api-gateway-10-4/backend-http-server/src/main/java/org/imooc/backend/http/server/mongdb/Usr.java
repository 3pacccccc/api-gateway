package org.imooc.backend.http.server.mongdb;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

/**
 * @PROJECT_NAME: api-gateway
 * @DESCRIPTION:
 * @USER: WuYang
 * @DATE: 2023/5/14 15:10
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Usr {
    @Id
    private String id;
    private String name;
    private int age;
}