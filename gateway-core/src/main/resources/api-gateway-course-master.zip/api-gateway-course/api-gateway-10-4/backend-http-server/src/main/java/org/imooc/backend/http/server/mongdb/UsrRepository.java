package org.imooc.backend.http.server.mongdb;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

public interface UsrRepository extends ReactiveMongoRepository<Usr,String> {
}
