package org.imooc.backend.http.server.webflux;

import org.imooc.backend.http.server.mongdb.Usr;
import org.imooc.backend.http.server.mongdb.UsrRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Duration;



@RestController
@RequestMapping(path = "/user")
public class UserCtl {
    @Autowired
    private UsrRepository usrRepository;

    @GetMapping(value = "/list")
    public Flux<Usr> getAll(){
        return usrRepository.findAll();
    }

    @GetMapping(value = "/listdelay",produces = MediaType.APPLICATION_STREAM_JSON_VALUE)
    public Flux<Usr> getAlldelay(){
        return usrRepository.findAll().delayElements(Duration.ofSeconds(1));
    }

    @GetMapping("/{id}")
    public Mono<ResponseEntity<Usr>> getUsr(@PathVariable String id){
        return usrRepository.findById(id)
                .map(getUsr->ResponseEntity.ok(getUsr))
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }

    @PostMapping("")
    public Mono<Usr> creatUser(@Validated Usr usr){
        return usrRepository.save(usr);
    }

    public Mono updateUser(@PathVariable(value = "id") String id,@Validated Usr usr){
        return usrRepository.findById(id)
                .flatMap(
                        existingUser->{existingUser.setName(usr.getName());
                            return usrRepository.save(existingUser);
                        })
                .map(updateUser->new ResponseEntity<>(updateUser, HttpStatus.OK))
                .defaultIfEmpty(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @DeleteMapping("/{id}")
    public Mono<ResponseEntity<Void>> deleteUser(@PathVariable(value = "id") String id){
        return usrRepository.findById(id)
                .flatMap(existingUser->usrRepository.delete(existingUser)
                        .then(Mono.just(new ResponseEntity<Void>(HttpStatus.OK))))
                .defaultIfEmpty(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }
}

