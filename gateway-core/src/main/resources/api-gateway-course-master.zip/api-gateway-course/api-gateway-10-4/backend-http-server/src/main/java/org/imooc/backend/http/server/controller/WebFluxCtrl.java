package org.imooc.backend.http.server.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

/**
 * @PROJECT_NAME: api-gateway
 * @DESCRIPTION:
 * @USER: WuYang
 * @DATE: 2023/5/14 14:17
 */
@RestController
public class WebFluxCtrl {
    @RequestMapping("/hellw")
    public Mono<String> helloworld(){
        return Mono.just("hello this mono world");
    }
}
