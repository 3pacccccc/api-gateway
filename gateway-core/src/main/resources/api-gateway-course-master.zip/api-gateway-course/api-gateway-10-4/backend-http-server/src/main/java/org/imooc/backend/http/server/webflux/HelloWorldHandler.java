package org.imooc.backend.http.server.webflux;


import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

/**
 * @PROJECT_NAME: api-gateway
 * @DESCRIPTION:
 * @USER: WuYang
 * @DATE: 2023/5/14 14:21
 */
@Component
public class HelloWorldHandler {
    public Mono<ServerResponse> sayHelloWord(ServerRequest  serverRequest){
        return ServerResponse.ok().contentType(MediaType.TEXT_PLAIN).body(Mono.just("this is webFlus demo"),String.class);
    }
}

